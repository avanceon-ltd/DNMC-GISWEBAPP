﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebAppForm.App_Code;

namespace WebAppForm
{
    /// <summary>
    /// Built by great "the yasir miraj"
    /// </summary>

    public partial class ICCSAlarm : System.Web.UI.Page
    {
        string siteName = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            txtArea.Attributes.Add("readonly", "readonly");

            if (!String.IsNullOrEmpty(Request.QueryString["SiteName"]))
                siteName = Request.QueryString["SiteName"];
            if (!Page.IsPostBack)
            {
                //if (!String.IsNullOrEmpty(Request.QueryString["Title"]))
                //{
                //    // Query string value is there so now use it
                //    txtTitle.Text = Convert.ToString(Request.QueryString["Title"]) + " - " + GetTitleId();
                //}

                FillICCSContacts(siteName);
                FillAlarmGrid();
                if (!String.IsNullOrEmpty(Request.QueryString["ReportedBy"]))
                {
                    lblReportedBy.Text = Convert.ToString(Request.QueryString["ReportedBy"]); ;
                }

                //if (!String.IsNullOrEmpty(Request.QueryString["Group"]))
                //{
                //    txtGroup.Text = Convert.ToString(Request.QueryString["Group"]); ;
                //}
                //if (!String.IsNullOrEmpty(Request.QueryString["Date"]))
                //{
                //    txtDateTime.Text = Convert.ToDateTime(Convert.ToString(Request.QueryString["Date"])).ToString("s");
                //}

                //txtDateTime.Text = DateTime.Now.ToString("s");
            }
        }

        void FillAlarmGrid()
        {
            if (!String.IsNullOrEmpty(Request.QueryString["SiteName"]))
            {
                string siteName = Request.QueryString["SiteName"];

                string query = @" SELECT Top(10) Source_HierarchicalObject,EventTime,Source_Object,Source_HierarchicalArea, comment,Source_Area 
                        FROM [Events]
                        WHERE  EventTime between  DATEADD(HOUR, -24, GETDATE())  AND GetDate()  
                        AND (Source_HierarchicalObject like '" + siteName + ".%' OR Source_HierarchicalObject = '"+ siteName + 
                        "') AND Priority < 950 AND Alarm_State = 'UNACK_ALM' ORDER BY EventTime DESC ";
                SqlDataSource1.SelectCommand = query;
                gvAlarms.DataBind();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                GenerateAlarm();
            }
        }

        //        {
        //  "AlarmID": 0,
        //  "AlarmTitle": "string",
        //  "Priority": 0,
        //  "Status": 0,
        //  "UnitID": "string",
        //  "FunctionArea": "string",
        //  "AlarmDate": "2020-01-21T11:47:55.974Z",
        //  "OwnerName": "string",
        //  "Address1": "string",
        //  "Address2": "string",
        //  "Address3": "string",
        //  "Address4": "string",
        //  "PostCode": "string",
        //  "AlarmContactNo": "string",
        //  "Region": "string",
        //  "Contact1": "string",
        //  "ContactTel1": "string",
        //  "Contact2": "string",
        //  "ContactTel2": "string",
        //  "Contact3": "string",
        //  "ContactTel3": "string",
        //  "AlarmDetails": "string"
        //}
        void GenerateAlarm()
        {
            string reqPayload = "";
            DateTime reqTime = DateTime.Now;
            string alarmId = "0";
            string respPayload = "";
            DateTime respTime;
            string operation = "";
            string RESULT;

            try
            {
                string createUri = WebConfigurationManager.AppSettings["AlarmUri"]; //"http://10.154.70.25/DTCApi/api/Alarms"; //"http://iccsintsrv01/DTCApi/api/Alarms"; //10.154.70.25
                string authValue = "c2NhZGRhOmFuZ2Vs";// System.Web.Configuration.WebConfigurationManager.AppSettings["FAUTH"];
                var httpWebRequest = (HttpWebRequest)WebRequest.Create(createUri);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                httpWebRequest.Headers["Authorization"] = authValue;

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    dynamic jsonReqeust = new JObject();


                    //Address1: Network(1)
                    //Address2: Framework(2)
                    //Address3: Catchments(3)
                    //Address4: Asset(4)
                    //Source_ProcessVariable => Title

                    string[] contactName = ddlName.SelectedItem.Text.Split(':');
                    string[] contactTel = ddlContacts.SelectedItem.Text.Split('-');

                    jsonReqeust.AlarmTitle = txtTitle.Text + " - " + GetTitleId();
                    jsonReqeust.Priority = ddlPriority.SelectedValue;
                    jsonReqeust.UnitID = "SCADA";
                    jsonReqeust.AlarmDate = DateTime.Now.ToString("s");
                    jsonReqeust.OwnerName = lblReportedBy.Text;
                    jsonReqeust.Address1 = contactName[0];// txtNetwork.Text;
                    jsonReqeust.Address2 = contactName[1];
                    jsonReqeust.Address3 = companyName.Value;
                    //jsonReqeust.Address4 = txtAsset.Text;
                    jsonReqeust.AlarmContactNo = contactTel[1];
                    jsonReqeust.Region = region.Value;
                    jsonReqeust.Contact1 = contact1.Value;// "Section Head";
                    jsonReqeust.ContactTel1 = contactTel1.Value; // "1234";
                    jsonReqeust.Contact2 = contact2.Value;// "Manager";
                    jsonReqeust.ContactTel2 = contactTel2.Value; // "4567";
                    jsonReqeust.Contact3 = contact3.Value; // "Supervisor";
                    jsonReqeust.ContactTel3 = contactTel3.Value;// "2233";
                    jsonReqeust.AlarmDetails = txtDetail.Text;

                    streamWriter.Write(jsonReqeust.ToString());

                    // set db parameters
                    reqTime = DateTime.Now;
                    reqPayload = jsonReqeust.ToString();
                    operation = "SCADA";
                }

                using (var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse())
                {
                    JsonTextReader jsonReader = new JsonTextReader(new StreamReader(httpResponse.GetResponseStream()));
                    var jsonObject = (JObject)JToken.ReadFrom(jsonReader);
                    var jsonResult = JObject.Parse(jsonObject.ToString());
                    if (jsonResult.SelectToken("ResponseCode").ToString().Equals("1"))
                    {
                        lblMessage.Text = "<b>" + jsonResult.SelectToken("ResponseMessage").ToString() + "</b>";
                        //gvAlarms.DataBind();
                        ClearControls();
                    }
                    else
                    {
                        lblMessage.Text = "<b>Error: </b>" + jsonResult.SelectToken("ResponseMessage").ToString() + " with Response Code: " + jsonResult.SelectToken("ResponseCode").ToString();
                    }

                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "showModal();", true);

                    //set db parameters
                    respPayload = jsonResult.ToString();
                    respTime = DateTime.Now;
                    alarmId = jsonResult.SelectToken("AlarmID").ToString();

                }
            }
            catch (WebException wex)
            {
                //JsonTextReader jsonReader = new JsonTextReader(new StreamReader(wex.Response.GetResponseStream()));
                //var jsonObject = (JObject)JToken.ReadFrom(jsonReader);
                //var jsonResult = JObject.Parse(jsonObject.ToString());
                EventLogging.LogEvents(wex.StackTrace);
                lblMessage.Text = "<b> Problem with the alarm generation. Please contact system administrator";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "showModal();", true);

                //set db parameters
                respPayload = wex.Message;
                respTime = DateTime.Now;

            }
            catch (Exception exp)
            {
                lblMessage.Text = exp.Message;
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "showModal();", true);
                respPayload = exp.Message;
                respTime = DateTime.Now;
            }

            LogEvent(reqPayload, reqTime, alarmId, respPayload, respTime, operation);

        }

        private void LogEvent(string reqPayload, DateTime reqTime, string alarmId, string respPayload, DateTime respTime, string operation)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["FuseConnectionString"].ConnectionString))
            {
                //con.Open();
                using (SqlCommand cmd = new SqlCommand("auditAlarmSP ", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@reqPayload", SqlDbType.Text).Value = reqPayload;
                    cmd.Parameters.AddWithValue("@reqTime", SqlDbType.DateTime).Value = reqTime;
                    cmd.Parameters.AddWithValue("@alarmId", SqlDbType.VarChar).Value = alarmId;
                    cmd.Parameters.AddWithValue("@respPayload", SqlDbType.Text).Value = respPayload;
                    cmd.Parameters.AddWithValue("@respTime", SqlDbType.DateTime).Value = respTime;
                    cmd.Parameters.AddWithValue("@operation", SqlDbType.VarChar).Value = operation;

                    cmd.Parameters.Add("@RESULT", SqlDbType.VarChar, 500);
                    cmd.Parameters["@RESULT"].Direction = ParameterDirection.Output;

                    con.Open();
                    int i = cmd.ExecuteNonQuery();
                    if (i == -1)
                    {
                        //txtTitle.Text = GetTitleId();
                    }
                }
            }
        }

        string GetTitleId()
        {
            string title = "";
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["FuseConnectionString"].ConnectionString))
            {
                //con.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT Max(id) + 1 AS TitleID FROM [auditAlarms]", con))
                {
                    cmd.CommandType = CommandType.Text;

                    con.Open();
                    object titleId = cmd.ExecuteScalar();
                    title = titleId.ToString(); //"SCADA-Alarm-" + titleId.ToString();
                }
            }

            return title;
        }


        private void ClearControls()
        {
            txtDetail.Text = "";
            txtTitle.Text = "";
            txtNetwork.Text = "";
            txtFramework.Text = "";
            txtArea.Text = "";
            txtAsset.Text = "";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //    Response.Redirect("~/CreateWorkOrder.aspx");
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Pop", "hideModal();", true);
        }

        void FillICCSContacts(string siteName)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CapitaConnectionString"].ConnectionString))
            {
                //con.Open();
                using (SqlCommand cmd = new SqlCommand())// "auditAlarmSP ", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "SELECT [ID],[PHONE_NUMBER],[NAME],[CATEGORY_ID],[ADDRESS1],[ADDRESS2],[ADDRESS3],[ADDRESS4],[COMMENT1],[COMMENT2] " +
            ",[PERSONAL],[NUMBER_ALIAS],[NUMBER1],[NUMBER_ALIAS1],[NUMBER2],[NUMBER_ALIAS2],[NUMBER3],[NUMBER_ALIAS3],[NUMBER4],[NUMBER_ALIAS4],[TITLE] " +
        " FROM [TELEPHONE_DIRECTORY].[dbo].[TELEPHONE_DETAILS] " +
        " WHERE CATEGORY_ID IN(SELECT ID FROM[dbo].[TELEPHONE_CATEGORY] WHERE CATEGORY_NAME = '" + siteName + "')";
                    cmd.Connection = con;

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    ddlName.Items.Clear();
                    ddlName.Items.Add(new ListItem("-- Select Contact --", "-1"));
                    while (reader.Read())
                    {
                        string name = reader["NAME"].ToString();
                        string designation = reader["TITLE"].ToString();
                        string fullName = designation + name;
                        string id = reader["ID"].ToString();
                        ddlName.Items.Add(new ListItem(fullName, id));
                    }
                }
            }

            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CapitaConnectionString"].ConnectionString))
            {
                //con.Open();
                using (SqlCommand cmd = new SqlCommand())// "auditAlarmSP ", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = " SELECT TOP(1) [ID],[REGION_NAME],[NATIONAL_REGION] FROM [TELEPHONE_DIRECTORY].[dbo].[REGION] " +
                    " WHERE ID IN(SELECT[REGION_ID] FROM[TELEPHONE_DIRECTORY].[dbo].[TELEPHONE_CATEGORY_REGION] " +
                    " WHERE CATEGORY_ID IN(SELECT ID FROM[dbo].[TELEPHONE_CATEGORY] WHERE CATEGORY_NAME = '" + siteName + "'))";
                    cmd.Connection = con;

                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        region.Value = reader["REGION_NAME"].ToString();
                    }
                }
            }
        }

        protected void gvAlarms_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Accessing BoundField Column.
            //string network, framework, catchment, asset;
            string alarmDate = gvAlarms.SelectedRow.Cells[1].Text;
            string title = gvAlarms.SelectedRow.Cells[2].Text;
            string description = gvAlarms.SelectedRow.Cells[3].Text;


            //txtDateTime.Text = alarmDate;
            txtTitle.Text = title;
            txtDetail.Text = description;
            string[] hierarchy = gvAlarms.SelectedRow.Cells[4].Text.Split('.');
            txtNetwork.Text = hierarchy[1];
            txtFramework.Text = hierarchy[2];
            txtArea.Text = hierarchy[3];
            txtAsset.Text = hierarchy[4];

            txtHierarchy.Text = txtNetwork.Text + "\\" + txtFramework.Text + "\\" + txtArea.Text + "\\" + txtAsset.Text;

            //Qatar.FW_Network.FW_South.CH_40.PS_40
            //Address1: Network(1)
            //Address2: Framework(2)
            //Address3: Catchments(3)
            //Address4: Asset(4)
            //Source_ProcessVariable => Title


        }

        protected void ddlName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlName.SelectedValue != "-1")
            {

                ddlContacts.Items.Clear();
                int id = Convert.ToInt32(ddlName.SelectedValue);
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CapitaConnectionString"].ConnectionString))
                {
                    //con.Open();
                    using (SqlCommand cmd = new SqlCommand())// "auditAlarmSP ", con))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.CommandText = "SELECT [ID],[PHONE_NUMBER],[NAME],[CATEGORY_ID],[ADDRESS1],[ADDRESS2],[ADDRESS3],[ADDRESS4],[COMMENT1],[COMMENT2] " +
                ",[PERSONAL],[NUMBER_ALIAS],[NUMBER1],[NUMBER_ALIAS1],[NUMBER2],[NUMBER_ALIAS2],[NUMBER3],[NUMBER_ALIAS3],[NUMBER4],[NUMBER_ALIAS4],[TITLE] " +
            " FROM [TELEPHONE_DIRECTORY].[dbo].[TELEPHONE_DETAILS] " +
            " WHERE ID = " + id;
                        cmd.Connection = con;

                        con.Open();
                        SqlDataReader reader = cmd.ExecuteReader();
                        //ddlName.Items.Clear();
                        while (reader.Read())
                        {
                            string contactSource1 = reader["NUMBER_ALIAS"].ToString();
                            string contactNumber1 = reader["PHONE_NUMBER"].ToString();
                            string fullContact = contactSource1 + " - " + contactNumber1;
                            if (!String.IsNullOrEmpty(contactSource1) || !String.IsNullOrEmpty(contactNumber1))
                                ddlContacts.Items.Add(new ListItem(fullContact, fullContact));

                            contactSource1 = reader["NUMBER_ALIAS1"].ToString();
                            contactNumber1 = reader["NUMBER1"].ToString();
                            fullContact = contactSource1 + " - " + contactNumber1;
                            if (!String.IsNullOrEmpty(contactSource1) || !String.IsNullOrEmpty(contactNumber1))
                                ddlContacts.Items.Add(new ListItem(fullContact, fullContact));

                            contactSource1 = reader["NUMBER_ALIAS2"].ToString();
                            contactNumber1 = reader["NUMBER2"].ToString();
                            fullContact = contactSource1 + " - " + contactNumber1;
                            if (!String.IsNullOrEmpty(contactSource1) || !String.IsNullOrEmpty(contactNumber1))
                                ddlContacts.Items.Add(new ListItem(fullContact, fullContact));

                            companyName.Value = reader["ADDRESS1"].ToString();
                            contact1.Value = reader["NUMBER_ALIAS"].ToString();
                            contactTel1.Value = reader["PHONE_NUMBER"].ToString(); ;
                            contact2.Value = reader["NUMBER_ALIAS1"].ToString();
                            contactTel2.Value = reader["NUMBER1"].ToString();
                            contact3.Value = reader["NUMBER_ALIAS2"].ToString();
                            contactTel3.Value = reader["NUMBER2"].ToString();
                        }
                    }
                }
            }
        }

        protected void ddlName_Init(object sender, EventArgs e)
        {
            FillICCSContacts(siteName);
        }
    }
}